<?php
include 'db_connect.php';

// Prepara y ejecuta la consulta SQL para obtener los datos
$sql = "SELECT * FROM quiz_form_data";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table border='1'>
    <tr>
    <th>ID</th>
    <th>Primer Nombre</th>
    <th>Apellido</th>
    <th>Usuario</th>
    <th>Email</th>
    <th>Teléfono</th>
    </tr>";

    // Muestra los datos en una tabla
    while($row = $result->fetch_assoc()) {
        echo "<tr>
        <td>" . $row["id"]. "</td>
        <td>" . $row["primer_nombre"]. "</td>
        <td>" . $row["apellido"]. "</td>
        <td>" . $row["usuario"]. "</td>
        <td>" . $row["email"]. "</td>
        <td>" . $row["telefono"]. "</td>
        </tr>";
    }
    echo "</table>";
} else {
    echo "0 resultados";
}
$conn->close();
?>
