<?php
include 'db_connect.php';

// Verifica que todos los campos requeridos estén presentes
if (isset($_POST['primer_nombre'], $_POST['apellido'], $_POST['usuario'], $_POST['email'], $_POST['telefono'], $_POST['contrasena'], $_POST['confirmar_contrasena'])) {
    // Escapa los valores para prevenir inyección SQL
    $primer_nombre = $conn->real_escape_string($_POST['primer_nombre']);
    $apellido = $conn->real_escape_string($_POST['apellido']);
    $usuario = $conn->real_escape_string($_POST['usuario']);
    $email = $conn->real_escape_string($_POST['email']);
    $telefono = $conn->real_escape_string($_POST['telefono']);
    $contrasena = $conn->real_escape_string($_POST['contrasena']);
    $confirmar_contrasena = $conn->real_escape_string($_POST['confirmar_contrasena']);

    // Verifica que las contraseñas coincidan
    if ($contrasena === $confirmar_contrasena) {
        // Encripta la contraseña antes de almacenarla
        $contrasena_hashed = password_hash($contrasena, PASSWORD_DEFAULT);

        // Inserta los datos en la base de datos
        $sql = "INSERT INTO quiz_form_data (primer_nombre, apellido, usuario, email, telefono, contrasena, confirmar_contrasena)
                VALUES ('$primer_nombre', '$apellido', '$usuario', '$email', '$telefono', '$contrasena_hashed', '$contrasena_hashed')";

        if ($conn->query($sql) === TRUE) {
            echo "Datos registrados exitosamente.";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Las contraseñas no coinciden.";
    }
} else {
    echo "Todos los campos son obligatorios.";
}

$conn->close();
?>
