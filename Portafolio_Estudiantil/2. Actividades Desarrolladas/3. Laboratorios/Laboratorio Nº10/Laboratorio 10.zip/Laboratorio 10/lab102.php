<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Definir los tipos de archivo permitidos y el tamaño máximo del archivo
    $tipos_permitidos = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
    $tamano_maximo_archivo = 1 * 1024 * 1024; // 1MB

    // Verificar si se ha subido un archivo sin errores
    if (isset($_FILES['nombre_archivo_cliente']) && $_FILES['nombre_archivo_cliente']['error'] == 0) {
        $archivo = $_FILES['nombre_archivo_cliente'];
        
        // Validar el tamaño del archivo
        if ($archivo['size'] > $tamano_maximo_archivo) {
            echo "Error: El archivo excede el tamaño máximo permitido de 1MB.";
        } 
        // Validar el tipo de archivo
        elseif (!in_array($archivo['type'], $tipos_permitidos)) {
            echo "Error: El archivo no es un formato válido. Solo se permiten archivos JPG, JPEG, PNG, y GIF.";
        } 
        // Si todas las validaciones pasan, procesar la subida del archivo
        else {
            $directorio_subida = 'uploads/';
            if (!file_exists($directorio_subida)) {
                mkdir($directorio_subida, 0755, true);
            }

            $ruta_subida = $directorio_subida . basename($archivo['name']);
            if (move_uploaded_file($archivo['tmp_name'], $ruta_subida)) {
                echo "El archivo ha sido subido exitosamente.";
            } else {
                echo "Error: Hubo un problema al subir el archivo.";
            }
        }
    } else {
        echo "Error: No se ha seleccionado ningún archivo o ha ocurrido un problema al subirlo.";
    }
}
?>
