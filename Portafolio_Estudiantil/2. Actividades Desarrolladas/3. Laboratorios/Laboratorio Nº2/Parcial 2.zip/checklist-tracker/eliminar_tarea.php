<?php
// Conexión a la base de datos
include 'includes/db.php';

// Obtener el ID de la tarea
$id = $_GET['id'];

// Eliminar la tarea de la base de datos
$mysqli->query("DELETE FROM tareas WHERE id = $id");

// Redirigir al usuario a la página principal
header('Location: index.php');
exit();
?>
