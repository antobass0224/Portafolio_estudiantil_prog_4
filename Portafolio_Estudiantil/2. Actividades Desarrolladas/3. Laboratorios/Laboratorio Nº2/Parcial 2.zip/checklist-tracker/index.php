<?php
include 'includes/db.php';

$tareas = [
    'por_hacer' => [],
    'en_progreso' => [],
    'terminadas' => []
];

$result = $mysqli->query("SELECT * FROM tareas");

while ($tarea = $result->fetch_assoc()) {
    $tareas[$tarea['estado']][] = $tarea;
}

$result->free();
$mysqli->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checklist Tracker</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Checklist Tracker</h1>
        <nav>
            <ul>
                <li><a href="index.php">Inicio</a></li>
                <li><a href="crear_tarea.php">Crear Tarea</a></li>
                <li><a href="reporte.php">Reporte</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <div class="task-categories">
            <div class="task-category" id="por_hacer">
                <h2>Por Hacer</h2>
                <?php foreach ($tareas['por_hacer'] as $tarea): ?>
                <div class="card">
                    <div class="card-header">
                        <h3><?php echo htmlspecialchars($tarea['titulo']); ?></h3>
                    </div>
                    <div class="card-body">
                        <p><?php echo htmlspecialchars($tarea['descripcion']); ?></p>
                        <p>Fecha de Compromiso: <?php echo htmlspecialchars($tarea['fecha_compromiso']); ?></p>
                    </div>
                    <div class="card-footer">
                        <a href="editar_tarea.php?id=<?php echo $tarea['id']; ?>" class="edit-task">Editar</a>
                        <a href="eliminar_tarea.php?id=<?php echo $tarea['id']; ?>" class="delete-task">Eliminar</a>
                        <a href="mover_tarea.php?id=<?php echo $tarea['id']; ?>&estado=en_progreso" class="move-task">Mover a En Progreso</a>
                        <a href="mover_tarea.php?id=<?php echo $tarea['id']; ?>&estado=terminadas" class="move-task">Mover a Terminadas</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="task-category" id="en_progreso">
                <h2>En Progreso</h2>
                <?php foreach ($tareas['en_progreso'] as $tarea): ?>
                <div class="card">
                    <div class="card-header">
                        <h3><?php echo htmlspecialchars($tarea['titulo']); ?></h3>
                    </div>
                    <div class="card-body">
                        <p><?php echo htmlspecialchars($tarea['descripcion']); ?></p>
                        <p>Fecha de Compromiso: <?php echo htmlspecialchars($tarea['fecha_compromiso']); ?></p>
                    </div>
                    <div class="card-footer">
                        <a href="editar_tarea.php?id=<?php echo $tarea['id']; ?>" class="edit-task">Editar</a>
                        <a href="eliminar_tarea.php?id=<?php echo $tarea['id']; ?>" class="delete-task">Eliminar</a>
                        <a href="mover_tarea.php?id=<?php echo $tarea['id']; ?>&estado=por_hacer" class="move-task">Mover a Por Hacer</a>
                        <a href="mover_tarea.php?id=<?php echo $tarea['id']; ?>&estado=terminadas" class="move-task">Mover a Terminadas</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="task-category" id="terminadas">
                <h2>Terminadas</h2>
                <?php foreach ($tareas['terminadas'] as $tarea): ?>
                <div class="card">
                    <div class="card-header">
                        <h3><?php echo htmlspecialchars($tarea['titulo']); ?></h3>
                    </div>
                    <div class="card-body">
                        <p><?php echo htmlspecialchars($tarea['descripcion']); ?></p>
                        <p>Fecha de Compromiso: <?php echo htmlspecialchars($tarea['fecha_compromiso']); ?></p>
                    </div>
                    <div class="card-footer">
                        <a href="editar_tarea.php?id=<?php echo $tarea['id']; ?>" class="edit-task">Editar</a>
                        <a href="eliminar_tarea.php?id=<?php echo $tarea['id']; ?>" class="delete-task">Eliminar</a>
                        <a href="mover_tarea.php?id=<?php echo $tarea['id']; ?>&estado=por_hacer" class="move-task">Mover a Por Hacer</a>
                        <a href="mover_tarea.php?id=<?php echo $tarea['id']; ?>&estado=en_progreso" class="move-task">Mover a En Progreso</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </main>
    <footer>
        <p>&copy; 2024 Checklist Tracker. Todos los derechos reservados.</p>
    </footer>
</body>
</html>
