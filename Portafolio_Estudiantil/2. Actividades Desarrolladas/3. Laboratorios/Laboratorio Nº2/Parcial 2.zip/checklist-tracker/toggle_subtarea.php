<?php
include 'includes/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tarea_id = intval($_POST['tarea_id']);
    $subtarea_id = intval($_POST['subtarea_id']);
    $completada = filter_var($_POST['completada'], FILTER_VALIDATE_BOOLEAN);

    $stmt = $mysqli->prepare("UPDATE subtareas SET completada = ? WHERE id = ? AND tarea_id = ?");
    $stmt->bind_param("iii", $completada, $subtarea_id, $tarea_id);

    if ($stmt->execute()) {
        echo "Success";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $mysqli->close();
}
?>
