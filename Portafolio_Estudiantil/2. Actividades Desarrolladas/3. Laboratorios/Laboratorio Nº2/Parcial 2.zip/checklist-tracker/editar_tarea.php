<?php
include 'includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $titulo = $_POST['titulo'];
    $descripcion = $_POST['descripcion'];
    $fecha_compromiso = $_POST['fecha_compromiso'];
    $estado = $_POST['estado'];

    $stmt = $mysqli->prepare("UPDATE tareas SET titulo = ?, descripcion = ?, fecha_compromiso = ?, estado = ? WHERE id = ?");
    $stmt->bind_param('ssssi', $titulo, $descripcion, $fecha_compromiso, $estado, $id);
    $stmt->execute();
    $stmt->close();

    header('Location: index.php');
    exit;
} else {
    $id = $_GET['id'];

    $stmt = $mysqli->prepare("SELECT * FROM tareas WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $tarea = $result->fetch_assoc();
    $stmt->close();
}
$mysqli->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Tarea</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Editar Tarea</h1>
        <nav>
            <ul>
                <li><a href="index.php">Inicio</a></li>
                <li><a href="crear_tarea.php">Crear Tarea</a></li>
                <li><a href="reporte.php">Reporte</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <form action="editar_tarea.php" method="post">
            <input type="hidden" name="id" value="<?php echo htmlspecialchars($tarea['id']); ?>">
            <label for="titulo">Título:</label>
            <input type="text" id="titulo" name="titulo" value="<?php echo htmlspecialchars($tarea['titulo']); ?>" required>
            <label for="descripcion">Descripción:</label>
            <textarea id="descripcion" name="descripcion" required><?php echo htmlspecialchars($tarea['descripcion']); ?></textarea>
            <label for="fecha_compromiso">Fecha de Compromiso:</label>
            <input type="date" id="fecha_compromiso" name="fecha_compromiso" value="<?php echo htmlspecialchars($tarea['fecha_compromiso']); ?>" required>
            <label for="estado">Estado:</label>
            <select id="estado" name="estado">
                <option value="por_hacer" <?php if ($tarea['estado'] == 'por_hacer') echo 'selected'; ?>>Por Hacer</option>
                <option value="en_progreso" <?php if ($tarea['estado'] == 'en_progreso') echo 'selected'; ?>>En Progreso</option>
                <option value="terminadas" <?php if ($tarea['estado'] == 'terminadas') echo 'selected'; ?>>Terminadas</option>
            </select>
            <button type="submit">Guardar Cambios</button>
        </form>
    </main>
    <footer>
        <p>&copy; 2024 Checklist Tracker. Todos los derechos reservados.</p>
    </footer>
</body>
</html>
