<?php
include 'includes/db.php';

// Verificar si se ha enviado el formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtener los datos del formulario
    $titulo = $mysqli->real_escape_string($_POST['titulo']);
    $descripcion = $mysqli->real_escape_string($_POST['descripcion']);
    $estado = $mysqli->real_escape_string($_POST['estado']);
    $fecha_compromiso = $mysqli->real_escape_string($_POST['fecha_compromiso']);
    $responsable = $mysqli->real_escape_string($_POST['responsable']);
    $tipo_tarea = $mysqli->real_escape_string($_POST['tipo_tarea']);
    $editado = 0; // Inicialmente no editado

    // Insertar la nueva tarea en la base de datos
    $query = "INSERT INTO tareas (titulo, descripcion, estado, fecha_compromiso, responsable, tipo_tarea, editado) VALUES ('$titulo', '$descripcion', '$estado', '$fecha_compromiso', '$responsable', '$tipo_tarea', '$editado')";
    
    if ($mysqli->query($query) === TRUE) {
        // Redirigir a la página principal después de crear la tarea
        header('Location: index.php');
    } else {
        echo "Error: " . $query . "<br>" . $mysqli->error;
    }

    $mysqli->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Tarea</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Crear Tarea</h1>
        <nav>
            <ul>
                <li><a href="index.php">Inicio</a></li>
                <li><a href="crear_tarea.php">Crear Tarea</a></li>
                <li><a href="reporte.php">Reporte</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <form action="crear_tarea.php" method="POST">
            <div class="form-group">
                <label for="titulo">Título:</label>
                <input type="text" id="titulo" name="titulo" required>
            </div>
            <div class="form-group">
                <label for="descripcion">Descripción:</label>
                <textarea id="descripcion" name="descripcion" required></textarea>
            </div>
            <div class="form-group">
                <label for="estado">Estado:</label>
                <select id="estado" name="estado" required>
                    <option value="por_hacer">Por Hacer</option>
                    <option value="en_progreso">En Progreso</option>
                    <option value="terminadas">Terminadas</option>
                </select>
            </div>
            <div class="form-group">
                <label for="fecha_compromiso">Fecha de Compromiso:</label>
                <input type="date" id="fecha_compromiso" name="fecha_compromiso" required>
            </div>
            <div class="form-group">
                <label for="responsable">Responsable:</label>
                <input type="text" id="responsable" name="responsable" required>
            </div>
            <div class="form-group">
                <label for="tipo_tarea">Tipo de Tarea:</label>
                <input type="text" id="tipo_tarea" name="tipo_tarea" required>
            </div>
            <button type="submit">Crear Tarea</button>
        </form>
    </main>
    <footer>
        <p>&copy; 2024 Checklist Tracker. Todos los derechos reservados.</p>
    </footer>
</body>
</html>
