<?php
// Conexión a la base de datos
include 'includes/db.php';

// Obtener el ID de la tarea y el nuevo estado
$id = $_GET['id'];
$estado = $_GET['estado'];

// Actualizar el estado de la tarea en la base de datos
$mysqli->query("UPDATE tareas SET estado = '$estado' WHERE id = $id");

// Redirigir al usuario a la página principal
header('Location: index.php');
exit();
?>
