<?php
$mysqli = new mysqli('localhost', 'root', '', 'checklist_tracker');

if ($mysqli->connect_error) {
    die('Error de Conexión (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
}
?>
