<footer>
        <p>&copy; <?php echo date('Y'); ?> Checklist Tracker. Todos los derechos reservados.</p>
    </footer>
</body>
</html>
