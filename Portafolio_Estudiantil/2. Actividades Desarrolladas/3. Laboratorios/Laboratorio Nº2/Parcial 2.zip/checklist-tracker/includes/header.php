<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checklist Tracker</title>
    <link rel="stylesheet" href="styles.css"> <!-- Enlaza tu archivo CSS aquí -->
    <script src="script.js" defer></script> <!-- Enlaza tu archivo JavaScript aquí -->
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="#por_hacer">Por Hacer</a></li>
                <li><a href="#en_progreso">En Progreso</a></li>
                <li><a href="#terminadas">Terminadas</a></li>
                <li><a href="#reportes">Reportes</a></li>
            </ul>
        </nav>
    </header>

    