<?php
include 'includes/db.php';

// Consulta para obtener todas las tareas
$query = "SELECT * FROM tareas";
$result = $mysqli->query($query);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reporte de Tareas</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Reporte de Tareas</h1>
        <nav>
            <ul>
                <li><a href="index.php">Inicio</a></li>
                <li><a href="crear_tarea.php">Crear Tarea</a></li>
                <li><a href="reporte.php">Reporte</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Título</th>
                    <th>Descripción</th>
                    <th>Estado</th>
                    <th>Fecha de Compromiso</th>
                    <th>Responsable</th>
                    <th>Tipo de Tarea</th>
                    <th>Editado</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['titulo']; ?></td>
                    <td><?php echo $row['descripcion']; ?></td>
                    <td><?php echo $row['estado']; ?></td>
                    <td><?php echo $row['fecha_compromiso']; ?></td>
                    <td><?php echo $row['responsable']; ?></td>
                    <td><?php echo $row['tipo_tarea']; ?></td>
                    <td><?php echo $row['editado'] ? 'Sí' : 'No'; ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </main>
    <footer>
        <p>&copy; 2024 Checklist Tracker. Todos los derechos reservados.</p>
    </footer>
</body>
</html>

<?php
$mysqli->close();
?>
